#include <bits/stdc++.h>

using namespace std;

//有数组int A[nSize]，当中隐藏若干0，其余非0.写一个函数，int F(int *p, int nsize)，
// 将0都移动到数组后面，非0数据移动到数组前面，保持有序。返回第一个为0元素的下标。
int F(int *p, int nsize) {
    int last = nsize - 1;
    for (int i = 0; i <= last; i++) {
        if (p[i] == 0) {
            swap(p[i], p[last]);
            i--;
            last--;
        }
    }
    return last;
}

int main() {
    int length = 1;
    int *p = new int[length];
    int nsize = 0;
    while (cin >> p[nsize]) {
        nsize++;
        if (nsize >= length) {
            length *= 2;
            int *p_next = new int[length];
            for (int _ = 0; _ < nsize; _++) p_next[_] = p[_];
            delete[] p;
            p = p_next;
        }
    }
    cout << F(p, nsize) + 1 << endl;
    return 0;
}