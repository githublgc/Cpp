#include <bits/stdc++.h>

using namespace std;

/*简单题——逆序输出*/

int main() {
    char s[10005];
    cin >> s;
    int l = 0, r = strlen(s) - 1;
    if (s[0] == '-') cout << "-", l++;
    while (s[r] == '0' && r > l) r--;
    for (int i = r; i >= l; i--) cout << s[i];
    cout << endl;
    return 0;
}