#include <bits/stdc++.h>
/*英雄的攻击力为A，血量为H；有N个怪物，第i个怪物的攻击力为A_i，
 * 血量为H_i；怪物或英雄的血量小于1则视为死亡；英雄将与怪物战斗，
 * 直到英雄死亡或所有怪物死亡。在每次战斗中，英雄都可以与一个活的怪物i战斗，
 * 经过战斗后怪物的血量减少A同时英雄的血量减少A_i，且英雄可以同一个怪物多次战斗。
 * 请判断英雄是否可以杀死所有怪物（即使英雄在杀死最后一个怪物之后死亡）。
 */
using namespace std;

int main() {
    int A, H, n;
    int a[10000], h[10000];
    cin >> A >> H >> n;
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 0; i < n; i++) cin >> h[i];
    int i;
    for (i = 0; i < n; i++) {
        H -= a[i] * (h[i] / A + (int) (h[i] % A != 0));
        if (H <= 0 && i != n - 1) {
            cout << "NO" << endl;
            return 0;
        }
    }
    if (H + a[n - 1] < 0) cout << "NO" << endl;
    else cout << "YES" << endl;
    return 0;
}