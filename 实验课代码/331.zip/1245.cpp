#include<bits/stdc++.h>

using namespace std;
int ans, m, L;

int s2i(const char *s) {
    int ret = 0, l = 0, r = L;
    for (int i = l; i < r; i++) ret = ret * 10 + s[i] - '0';
    return ret;
}

void dfs(char *s, int x, int remain) {
    ans = min(ans, s2i(s));
    if (remain == 0 || x >= strlen(s)) return;
    char t = s[x];
    for (int i = x + 1; i < L; i++) {
        t = min(t, (x == 0 && s[i] == '0' ? '9' : s[i]));
    }
    if (t == s[x]) {
        dfs(s, x + 1, remain);
    } else {
        for (int i = x + 1; i < L; i++) {
            if (s[i] == t) {
                swap(s[x], s[i]);
                dfs(s, x + 1, remain - 1);
                swap(s[x], s[i]);
            }
        }
    }
}

int main() {
    char s[20];
    while (cin >> s >> m) {
        L = strlen(s);
        ans = s2i(s);
        dfs(s, 0, m);
        cout << ans << endl;
    }
    return 0;
}