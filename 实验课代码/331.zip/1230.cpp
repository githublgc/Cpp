#include <bits/stdc++.h>

using namespace std;

void swap(int *a, int *b) {
    *a ^= *b;
    *b ^= *a;
}

int main() {
    int A[10 + 1];
    for (int i = 0; i < 10; i++) {
        cin >> A[i];
    }
    for (int i = 0; i < 5; i++) {
        swap(A[i], A[10 - i - 1]);
    }
    for (int i = 0; i < 10; i++) {
        cout << A[i] << " \n"[i == 9];
    }
    return 0;
}