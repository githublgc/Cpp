#include <bits/stdc++.h>
//给你一个字符串（长度<=1000），输出字符串中最长重复子串的长度。
using namespace std;


int main() {
    char s[1005];
    cin.getline(s, 1000);
    int l = strlen(s);
    int ans = 0;
    int nl = 1;
    for (int i = 1; i < l; i++) {
        if (s[i] == s[i - 1]) nl++, ans = max(ans, nl);
        else nl = 1, ans = max(ans, nl);
    }
    cout << ans << endl;
    return 0;
}
