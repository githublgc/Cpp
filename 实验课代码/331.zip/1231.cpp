#include <bits/stdc++.h>

using namespace std;

//读入一个整数n（0<=n<=2000），利用指针生成大小为n的动态int型数组，读入n个整数，对n个整数进行排序后输出；
void sort1(const int *begin, const int *end) {
    for (int *i = (int *) begin; i < end; i++)
        for (int *j = i + 1; j < end; j++)
            if (*i > *j) {
                swap(*i, *j);
            }
}

int main() {
    int n;
    cin >> n;
    int *a = new int[n];
    for (int i = 0; i < n; i++) cin >> a[i];
    sort1(a, a + n);
    for (int i = 0; i < n; i++) cout << a[i] << " \n"[i == n - 1];
    return 0;
}