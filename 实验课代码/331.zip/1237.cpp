#include <bits/stdc++.h>
using namespace std;

void sort1(const int *begin, const int *end) {
    for (int *i = (int *) begin; i < end; i++)
        for (int *j = i + 1; j < end; j++)
            if (*i > *j) {
                swap(*i, *j);
            }
}

int main() {
    int n;
    cin >> n;
    int **a = new int *[n];
    for (int i = 1; i < n; i++) {
        a[i - 1] = new int[(1 << i)];
        for (int j = 0; j < (1 << i); j++) {
            cin >> a[i - 1][j];
        }
    }
    a[n - 1] = new int[(1 << n) - 2];
    for (int i = 1, p = 0; i < n; i++) {
        for (int j = 0; j < (1 << i); j++, p++) {
            a[n - 1][p] = a[i - 1][j];
        }
    }
    sort1(a[n - 1], a[n - 1] + (1 << n) - 2);
    for (int i = 1; i < n; i++) {
        for (int j = 0; j < (1 << i); j++) {
            cout << a[i - 1][j] << " \n"[j == (1 << i) - 1];
        }
    }
    for (int i = 0; i < (1 << n) - 2; i++) {
        cout << a[n - 1][i] << " \n"[i == (1 << n) - 3];
    }
    return 0;
}