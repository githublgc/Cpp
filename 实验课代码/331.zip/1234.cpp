#include <bits/stdc++.h>

using namespace std;


int main() {
    char a[10005];
    char b[10005];
    cin >> a;
    cin >> b;
    size_t al = strlen(a);
    size_t bl = strlen(b);
    if (al != bl) {
        cout << "F" << endl;
        return 0;
    }
    for (int i = 0; i < al; i++) {
        if (a[i] != b[i]) {
            cout << "F" << endl;
            return 0;
        }
    }
    cout << "T" << endl;
    return 0;
}