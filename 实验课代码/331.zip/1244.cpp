#include <bits/stdc++.h>

using namespace std;

struct String {
    char *a = nullptr;
    int length = 0;
};

int get_int(char *s, int &l) {
    int ans = 0;
    for (;; l++) {
        if ('0' <= s[l] && s[l] <= '9') ans = ans * 10 + s[l] - '0';
        else return ans;
    }
}

int get_next(char *s, int l) {
    int ls = 0;
    for (int i = l;; i++) {
        if (s[i] == '[') ls++;
        if (s[i] == ']') {
            if (ls) ls--;
            else return i;
        }
    }
}

String concat(String a, char x) {
    String b;
    b.a = new char[a.length + 1 + 1];
    b.length = a.length + 1;
    if (a.length)
        strncpy(b.a, a.a, a.length);
    b.a[a.length] = x;
    b.a[b.length] = 0;
    if (a.length)
        delete[] a.a;
    return b;
}

String concat(String a, String b) {
    String c;
    c.a = new char[a.length + b.length + 1];
    c.length = a.length + b.length;
    if (a.length)
        strncpy(c.a, a.a, a.length);
    if (b.length)
        strncpy(c.a + a.length, b.a, b.length);
    if (a.length)
        delete[] a.a;
    c.a[c.length] = 0;
    return c;
}

String get_s(char *a, int l, int r) {
    String ans;
    for (int i = l; i <= r; i++) {
        if (a[i] != '[' && a[i] != ']') ans = concat(ans, a[i]);
        if (a[i] == '[') {
            i++;
            int p = get_int(a, i);
            int j = get_next(a, i);
            String tmp = get_s(a, i, j - 1);
            for (int _ = 0; _ < p; _++) ans = concat(ans, tmp);
            i = j;
        }
    }
    return ans;
}

int main() {
    char s[100005];
    cin.getline(s, 100005);
    cout << get_s(s, 0, strlen(s) - 1).a << endl;
    return 0;
}