#include <bits/stdc++.h>

using namespace std;

int f(int a[][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = i + 1; j < 3; j++) {
            swap(a[i][j],a[j][i]);
        }
    }
}

int main() {
    int a[3][3] = {0};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> a[i][j];
        }
    }
    f(a);
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << a[i][j] << " \n"[j == 2];
        }
    }
    return 0;
}