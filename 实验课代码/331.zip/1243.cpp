#include <bits/stdc++.h>

using namespace std;


int main() {
    int n;
    cin >> n;
    double **M = new double *[n], **A = new double *[n];
    for (int i = 0; i < n; i++) {
        M[i] = new double[n];
        A[i] = new double[n];
        for (int j = 0; j < n; j++) {
            cin >> M[i][j];
            A[i][j]=0.0;
        }
        A[i][i] = 1.0;

    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i != j) {
                double p = M[j][i] / M[i][i];
                for (int k = 0; k < n; k++) {
                    M[j][k] -= p * M[i][k];
                    A[j][k] -= p * A[i][k];
                }
            }
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << fixed << setprecision(4) << A[i][j] / M[i][i] << " ";
        }
        cout << endl;
    }
    return 0;
}
